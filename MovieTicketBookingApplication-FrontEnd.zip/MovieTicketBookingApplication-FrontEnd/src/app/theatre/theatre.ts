export class Theatre {
  public theatreId: number;
  public theatreName: string;
  public managerName: string;
  public theatreCity: string;
  public managerContact: string;
  screen: any;
}
