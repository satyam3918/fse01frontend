export class Show {
  public showId: number;
  public showName: string;
  public showEndTime: Date;
  public showStartTime: Date;
  public showDate: Date;
}
