export class Ticket {
  public ticketId: number;
  public noOfSeats: number;
  public seats: any[];
}
